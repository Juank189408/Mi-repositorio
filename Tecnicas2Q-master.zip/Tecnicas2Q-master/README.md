# Tecnicas2Q
Curso tecnicas de programacion 2Q

## Semana 1
Creacion de repo
Ejercicios introdutorios a **C#**
