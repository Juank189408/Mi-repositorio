﻿using SistemaVentas.Modelos;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace SistemaVentas.Datos
{
    public class FacturaData
    {
        private const string FilePath = "facturas.csv";

        public List<Factura> CargarFacturas()
        {
            var facturas = new List<Factura>();
            if (File.Exists(FilePath))
            {
                var lines = File.ReadAllLines(FilePath);
                foreach (var line in lines.Skip(1))
                {
                    var values = line.Split(',');
                    var factura = new Factura
                    {
                        Id = int.Parse(values[0]),
                        ClienteId = int.Parse(values[1]),
                        Productos = values[2].Split(';').Select(p => new Producto { Id = int.Parse(p) }).ToList(),
                        Total = decimal.Parse(values[3]),
                        Fecha = DateTime.Parse(values[4])
                    };
                    facturas.Add(factura);
                }
            }
            return facturas;
        }

        public void GuardarFacturas(List<Factura> facturas)
        {
            var lines = new List<string> { "Id,ClienteId,Productos,Total,Fecha" };
            lines.AddRange(facturas.Select(f => $"{f.Id},{f.ClienteId},{string.Join(";", f.Productos.Select(p => p.Id))},{f.Total},{f.Fecha}"));
            File.WriteAllLines(FilePath, lines);
        }
    }
}
