﻿using SistemaVentas.Modelos;
using SistemaVentas.Datos;
using System.Collections.Generic;

namespace SistemaVentas.Controladores
{
    public class FacturaController
    {
        private readonly FacturaData _facturaData;

        public FacturaController()
        {
            _facturaData = new FacturaData();
        }

        public void GenerarFactura(Factura factura)
        {
            var facturas = _facturaData.CargarFacturas();
            facturas.Add(factura);
            _facturaData.GuardarFacturas(facturas);
        }

        public List<Factura> ObtenerFacturas()
        {
            return _facturaData.CargarFacturas();
        }
    }
}
