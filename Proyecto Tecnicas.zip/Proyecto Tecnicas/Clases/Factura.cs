﻿using System.Collections.Generic;
using System;

namespace SistemaVentas.Modelos
{
    public class Factura
    {
        public int Id { get; set; }
        public int ClienteId { get; set; }
        public List<Producto> Productos { get; set; }
        public decimal Total { get; set; }
        public DateTime Fecha { get; set; }
    }
}
