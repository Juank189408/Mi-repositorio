﻿namespace SistemaVentas.Modelos
{
    public class MetodoPago
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
    }
}
