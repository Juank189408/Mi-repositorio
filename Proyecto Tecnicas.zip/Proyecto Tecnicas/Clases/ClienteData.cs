﻿using SistemaVentas.Modelos;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace SistemaVentas.Datos
{
    public class ClienteData
    {
        private const string FilePath = "clientes.csv";

        public List<Cliente> CargarClientes()
        {
            var clientes = new List<Cliente>();
            if (File.Exists(FilePath))
            {
                var lines = File.ReadAllLines(FilePath);
                foreach (var line in lines.Skip(1))
                {
                    var values = line.Split(',');
                    var cliente = new Cliente
                    {
                        Id = int.Parse(values[0]),
                        Nombre = values[1],
                        Direccion = values[2],
                        Telefono = values[3]
                    };
                    clientes.Add(cliente);
                }
            }
            return clientes;
        }

        public void GuardarClientes(List<Cliente> clientes)
        {
            var lines = new List<string> { "Id,Nombre,Direccion,Telefono" };
            lines.AddRange(clientes.Select(c => $"{c.Id},{c.Nombre},{c.Direccion},{c.Telefono}"));
            File.WriteAllLines(FilePath, lines);
        }

    }
}
