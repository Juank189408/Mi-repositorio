﻿using SistemaVentas.Modelos;
using SistemaVentas.Datos;
using System.Collections.Generic;

namespace SistemaVentas.Controladores
{
    public class ProductoController
    {
        private readonly ProductoData _productoData;

        public ProductoController()
        {
            _productoData = new ProductoData();
        }

        public List<Producto> ObtenerProductos()
        {
            return _productoData.CargarProductos();
        }

        public void AgregarProducto(Producto producto)
        {
            var productos = _productoData.CargarProductos();
            productos.Add(producto);
            _productoData.GuardarProductos(productos);
        }

        public void EditarProducto(Producto producto)
        {
            var productos = _productoData.CargarProductos();
            var productoExistente = productos.Find(p => p.Id == producto.Id);
            if (productoExistente != null)
            {
                productoExistente.Nombre = producto.Nombre;
                productoExistente.Cantidad = producto.Cantidad;
                productoExistente.Precio = producto.Precio;
                _productoData.GuardarProductos(productos);
            }
        }

        public void EliminarProducto(int id)
        {
            var productos = _productoData.CargarProductos();
            var producto = productos.Find(p => p.Id == id);
            if (producto != null)
            {
                productos.Remove(producto);
                _productoData.GuardarProductos(productos);
            }
        }
    }
}
