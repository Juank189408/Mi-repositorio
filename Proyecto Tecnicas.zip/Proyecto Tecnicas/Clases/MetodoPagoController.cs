﻿using SistemaVentas.Modelos;
using SistemaVentas.Datos;
using System.Collections.Generic;

namespace SistemaVentas.Controladores
{
    public class MetodoPagoController
    {
        private readonly MetodoPagoData _metodoPagoData;

        public MetodoPagoController()
        {
            _metodoPagoData = new MetodoPagoData();
        }

        public List<MetodoPago> ObtenerMetodosPago()
        {
            return _metodoPagoData.CargarMetodosPago();
        }

        public void AgregarMetodoPago(MetodoPago metodoPago)
        {
            var metodosPago = _metodoPagoData.CargarMetodosPago();
            metodosPago.Add(metodoPago);
            _metodoPagoData.GuardarMetodosPago(metodosPago);
        }
    }
}
