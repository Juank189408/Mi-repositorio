﻿using SistemaVentas.Modelos;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace SistemaVentas.Datos
{
    public class ProductoData
    {
        private const string FilePath = "productos.csv";

        public List<Producto> CargarProductos()
        {
            var productos = new List<Producto>();
            if (File.Exists(FilePath))
            {
                var lines = File.ReadAllLines(FilePath);
                foreach (var line in lines.Skip(1))
                {
                    var values = line.Split(',');
                    var producto = new Producto
                    {
                        Id = int.Parse(values[0]),
                        Nombre = values[1],
                        Cantidad = int.Parse(values[2]),
                        Precio = decimal.Parse(values[3])
                    };
                    productos.Add(producto);
                }
            }
            return productos;
        }

        public void GuardarProductos(List<Producto> productos)
        {
            var lines = new List<string> { "Id,Nombre,Cantidad,Precio" };
            lines.AddRange(productos.Select(p => $"{p.Id},{p.Nombre},{p.Cantidad},{p.Precio}"));
            File.WriteAllLines(FilePath, lines);
        }
    }
}
