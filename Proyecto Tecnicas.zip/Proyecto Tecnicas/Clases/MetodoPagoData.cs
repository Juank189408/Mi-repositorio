﻿using SistemaVentas.Modelos;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace SistemaVentas.Datos
{
    public class MetodoPagoData
    {
        private const string FilePath = "metodos_pago.csv";

        public List<MetodoPago> CargarMetodosPago()
        {
            var metodosPago = new List<MetodoPago>();
            if (File.Exists(FilePath))
            {
                var lines = File.ReadAllLines(FilePath);
                foreach (var line in lines.Skip(1))
                {
                    var values = line.Split(',');
                    var metodoPago = new MetodoPago
                    {
                        Id = int.Parse(values[0]),
                        Nombre = values[1]
                    };
                    metodosPago.Add(metodoPago);
                }
            }
            return metodosPago;
        }

        public void GuardarMetodosPago(List<MetodoPago> metodosPago)
        {
            var lines = new List<string> { "Id,Nombre" };
            lines.AddRange(metodosPago.Select(m => $"{m.Id},{m.Nombre}"));
            File.WriteAllLines(FilePath, lines);
        }
    }
}
