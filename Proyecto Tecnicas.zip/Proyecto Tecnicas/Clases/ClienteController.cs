﻿using SistemaVentas.Modelos;
using SistemaVentas.Datos;
using System.Collections.Generic;

namespace SistemaVentas.Controladores
{
    public class ClienteController
    {
        private readonly ClienteData _clienteData;

        public ClienteController()
        {
            _clienteData = new ClienteData();
        }

        public List<Cliente> ObtenerClientes()
        {
            return _clienteData.CargarClientes();
        }

        public void AgregarCliente(Cliente cliente)
        {
            var clientes = _clienteData.CargarClientes();
            clientes.Add(cliente);
            _clienteData.GuardarClientes(clientes);
        }
    }
}
