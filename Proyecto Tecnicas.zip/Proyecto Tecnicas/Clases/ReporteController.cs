﻿using SistemaVentas.Modelos;
using SistemaVentas.Datos;
using System.Collections.Generic;
using System.Linq;
using System;

namespace SistemaVentas.Controladores
{
    public class ReporteController
    {
        private readonly FacturaData _facturaData;

        public ReporteController()
        {
            _facturaData = new FacturaData();
        }

        public List<Factura> ObtenerFacturas()
        {
            return _facturaData.CargarFacturas();
        }

        public List<Factura> ObtenerFacturasPorFecha(DateTime fechaInicio, DateTime fechaFin)
        {
            var facturas = _facturaData.CargarFacturas();
            return facturas.Where(f => f.Fecha >= fechaInicio && f.Fecha <= fechaFin).ToList();
        }

        public List<Producto> ObtenerProductosMasVendidos()
        {
            var facturas = _facturaData.CargarFacturas();
            var productos = facturas.SelectMany(f => f.Productos).GroupBy(p => p.Id)
                                    .Select(g => new Producto { Id = g.Key, Cantidad = g.Count() })
                                    .OrderByDescending(p => p.Cantidad).ToList();
            return productos;
        }
    }
}
