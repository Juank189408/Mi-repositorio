﻿using SistemaVentas.Controladores;
using SistemaVentas.Modelos;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Proyecto_Tecnicas
{
    public partial class Form1 : Form
    {
        private ProductoController _productoController;
        private FacturaController _facturaController;
        private ReporteController _reporteController;
        private ClienteController _clienteController;
        private MetodoPagoController _metodoPagoController;

        public Form1()
        {
            InitializeComponent();
            _productoController = new ProductoController();
            _facturaController = new FacturaController();
            _reporteController = new ReporteController();
            _clienteController = new ClienteController();
            _metodoPagoController = new MetodoPagoController();
            CargarProductos();
        }

        private void CargarProductos()
        {
            var productos = _productoController.ObtenerProductos();
            dgvProductos.DataSource = productos;
        }

        private void btnAgregarProducto_Click(object sender, EventArgs e)
        {
            var producto = new Producto
            {
                Id = GenerarIdUnico(), 
                Nombre = "Nuevo Producto",
                Cantidad = 10,
                Precio = 100.00m
            };
            _productoController.AgregarProducto(producto);
            CargarProductos();
        }

        private void btnEditarProducto_Click(object sender, EventArgs e)
        {
            if (dgvProductos.SelectedRows.Count > 0)
            {
                var producto = (Producto)dgvProductos.SelectedRows[0].DataBoundItem;
                producto.Nombre = "Producto Editado";
                _productoController.EditarProducto(producto);
                CargarProductos();
            }
        }

        private void btnEliminarProducto_Click(object sender, EventArgs e)
        {
            if (dgvProductos.SelectedRows.Count > 0)
            {
                var producto = (Producto)dgvProductos.SelectedRows[0].DataBoundItem;
                _productoController.EliminarProducto(producto.Id);
                CargarProductos();
            }
        }

        private void btnGenerarFactura_Click(object sender, EventArgs e)
        {
            var factura = new Factura
            {
                Id = GenerarIdUnico(), 
                ClienteId = 1, 
                Productos = new List<Producto> { new Producto { Id = 1, Nombre = "Producto", Cantidad = 1, Precio = 100.00m } },
                Total = 100.00m,
                Fecha = DateTime.Now
            };
            _facturaController.GenerarFactura(factura);
        }

        private void btnVerReportes_Click(object sender, EventArgs e)
        {
            var reportes = _reporteController.ObtenerFacturas();
            
            MessageBox.Show("Reportes generados: " + reportes.Count);
        }

        private void btnGestionClientes_Click(object sender, EventArgs e)
        {
            var clientes = _clienteController.ObtenerClientes();
            
            MessageBox.Show("Clientes cargados: " + clientes.Count);
        }

        private void btnMetodosPago_Click(object sender, EventArgs e)
        {
            var metodosPago = _metodoPagoController.ObtenerMetodosPago();
            
            MessageBox.Show("Métodos de pago cargados: " + metodosPago.Count);
        }

        private int GenerarIdUnico()
        {
            
            return new Random().Next(1, 1000);
        }
        private void btnAgregarCliente_Click(object sender, EventArgs e)
        {
            var cliente = new Cliente
            {
                Id = GenerarIdUnico(),
                Nombre = "Nuevo Cliente",
                Direccion = "Dirección Desconocida",
                Telefono = "0000000000"
            };
            _clienteController.AgregarCliente(cliente);
            MessageBox.Show("Cliente agregado exitosamente.");
        }

    }
}
